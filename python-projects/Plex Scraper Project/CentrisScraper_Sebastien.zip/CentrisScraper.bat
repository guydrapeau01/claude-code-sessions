@echo off
setlocal EnableDelayedExpansion

set SCRIPT_DIR=%~dp0
set APP_DIR=%LOCALAPPDATA%\CentrisScraper
set LOG=%SCRIPT_DIR%launch_log.txt
set READY=%APP_DIR%\.ready

echo === %date% %time% === > "%LOG%"
echo Script dir: %SCRIPT_DIR% >> "%LOG%"

:: ── Check if Python is already installed ─────────────────────────────────────
python --version >nul 2>&1
if not errorlevel 1 goto PYTHON_OK

:: ── Python not found — install it silently ───────────────────────────────────
echo Python not found. Installing automatically... >> "%LOG%"
echo.
echo  Installing Python (this takes about 1 minute)...
echo  Please wait...
echo.

mkdir "%APP_DIR%" 2>nul

:: Download Python 3.11 embedded installer (~25MB)
set PY_URL=https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe
set PY_EXE=%APP_DIR%\python_installer.exe

echo Downloading Python installer... >> "%LOG%"
powershell -Command "& {[Net.ServicePointManager]::SecurityProtocol='Tls12'; Invoke-WebRequest -Uri '%PY_URL%' -OutFile '%PY_EXE%'}" >> "%LOG%" 2>&1

if not exist "%PY_EXE%" (
    echo FAILED to download Python >> "%LOG%"
    start notepad "%LOG%"
    msg * "Failed to download Python. Check your internet connection."
    exit /b 1
)

:: Install Python silently for current user, add to PATH
echo Installing Python silently... >> "%LOG%"
"%PY_EXE%" /passive InstallAllUsers=0 PrependPath=1 Include_launcher=0 >> "%LOG%" 2>&1

:: Clean up installer
del "%PY_EXE%" 2>nul

:: Refresh PATH so python is now available in this session
for /f "tokens=*" %%p in ('powershell -Command "[System.Environment]::GetEnvironmentVariable(\"PATH\",\"User\")"') do set "PATH=%%p;%PATH%"

:: Verify
python --version >nul 2>&1
if errorlevel 1 (
    echo Python install failed >> "%LOG%"
    start notepad "%LOG%"
    msg * "Python installation failed. See log for details."
    exit /b 1
)
echo Python installed successfully >> "%LOG%"

:PYTHON_OK
python --version >> "%LOG%" 2>&1

:: ── First-time setup ─────────────────────────────────────────────────────────
if exist "%READY%" goto LAUNCH

echo First-time setup... >> "%LOG%"
mkdir "%APP_DIR%" 2>nul

echo.
echo  Setting up Centris Scraper (one-time, ~3 minutes)...
echo  Please wait...
echo.

echo Installing packages... >> "%LOG%"
python -m pip install playwright openpyxl --quiet --no-warn-script-location >> "%LOG%" 2>&1
if errorlevel 1 (
    echo PIP FAILED >> "%LOG%"
    start notepad "%LOG%"
    exit /b 1
)

echo Installing Chromium browser... >> "%LOG%"
set PLAYWRIGHT_BROWSERS_PATH=%APP_DIR%\browsers
python -m playwright install chromium >> "%LOG%" 2>&1
if errorlevel 1 (
    echo CHROMIUM FAILED >> "%LOG%"
    start notepad "%LOG%"
    exit /b 1
)

echo ready > "%READY%"
echo Setup complete >> "%LOG%"

:LAUNCH
echo Launching app... >> "%LOG%"
set PLAYWRIGHT_BROWSERS_PATH=%APP_DIR%\browsers
python "%SCRIPT_DIR%centris_gui.py" >> "%LOG%" 2>&1
if errorlevel 1 (
    start notepad "%LOG%"
)

endlocal
